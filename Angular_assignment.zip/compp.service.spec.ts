import { TestBed } from '@angular/core/testing';

import { ComppService } from './compp.service';

describe('ComppService', () => {
  let service: ComppService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ComppService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
