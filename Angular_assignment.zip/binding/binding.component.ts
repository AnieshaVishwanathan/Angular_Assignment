import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binding',
  templateUrl: './binding.component.html',
  styleUrls: ['./binding.component.css']
})
export class BindingComponent implements OnInit {

  input_text: string = '';
  input_text1: string = '';
  input_text2: string = '';
  input_text3: string = '';
  input_text4: string = '';


  items = this.cart.getItems();
  checkOutForm = this.formBuilder.group({
    name: "",
    address: ""
  });
  total = this.cart.getTotal();

  formSubmitHandler() {
    this.items = this.cart.clearCart();
    window.alert("Check console");
    console.log("Successfully ordered", this.checkOutForm.value);
    this.checkOutForm.reset();
  }

  removeItemHandler(id: number) {
    this.cart.removeFromCart(id);
    this.items = this.cart.getItems();
    this.total = this.cart.getTotal();
  }

  constructor(private cart: CartService, private formBuilder: FormBuilder) {}
}
 

}
