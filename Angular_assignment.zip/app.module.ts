import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {
  HttpClientModule
} from '@angular/common/http';
import { RouterModule } from "@angular/router";
import { ReactiveFormsModule } from "@angular/forms";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TopBarComponent } from "./top-bar/top-bar.component";
import {FormsModule} from '@angular/forms';
import { BindingComponent } from './binding/binding.component';
import { AddCompComponent } from './add-comp/add-comp.component';
import { DeleteCompComponent } from './delete-comp/delete-comp.component';
import { UpdateCompComponent } from './update-comp/update-comp.component';
import { ComppService } from "./compp.service";
@NgModule({
  declarations: [
    AppComponent,
    
    
    BindingComponent,
    AddCompComponent,
    DeleteCompComponent,
    UpdateCompComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ComppService,
    RouterModule.forRoot([{ path: "", component: ProductListComponent },
    { path: "products/:productId", component: ProductDetailsComponent },
    { path: "cart", component: BindingComponent }
  

    ]),
    ReactiveFormsModule,
    HttpClientModule
    TopBarComponent,
    ProductListComponent,
    ProductAlertsComponent,
    ProductDetailsComponent,
    BindingComponent
  ],
  providers: [ComppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
