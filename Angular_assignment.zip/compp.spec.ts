import { Compp } from './compp';

describe('Compp', () => {
  it('should create an instance', () => {
    expect(new Compp()).toBeTruthy();
  });
});
